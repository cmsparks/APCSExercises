/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fallingsand;

import java.awt.*;
import java.util.*;

public class SandLab
{
  public static void main(String[] args)
  {
    SandLab lab = new SandLab(120, 80);
    lab.run();
  }
  
  //add constants for particle types here
  public static final int EMPTY = 0;
  public static final int METAL = 1;
  public static final int SAND = 2;
    public static final int WATER = 3;
  
  //do not add any more fields
  private int[][] grid;
  private SandDisplay display;
  
  public SandLab(int numRows, int numCols)
  {
    String[] names;
    names = new String[4];
    names[EMPTY] = "Empty";
    names[METAL] = "Metal";
    names[SAND] = "Sand";
    names[WATER] = "Water";
    display = new SandDisplay("Falling Sand", numRows, numCols, names);
    grid = new int[numRows][numCols];
  }
  
  //called when the user clicks on a location using the given tool
  private void locationClicked(int row, int col, int tool)
  {
      grid[row][col] = tool;
  }

  //copies each element of grid into the display
  public void updateDisplay()
  {
      for(int r = 0; r<grid.length; r++)
      {
          for(int c = 0; c<grid[0].length; c++)
          {
              if(grid[r][c]==EMPTY)
              {
                  display.setColor(r, c, Color.BLACK);
              }
              if(grid[r][c]==METAL)
              {
                  display.setColor(r, c, Color.GRAY);
              }
              if(grid[r][c]==SAND)
              {
                  display.setColor(r, c, Color.YELLOW);
              }
              if(grid[r][c]==WATER)
              {
                  display.setColor(r, c, Color.BLUE);
              }
          }
      }
  }

  //called repeatedly.
  //causes one random particle to maybe do something.
  public void step()
  {
      Random rand = new Random();
      Random rand1 = new Random();
      int randCol = rand.nextInt(grid[0].length);
      int randRow = rand1.nextInt(grid.length);
      if(grid[randRow][randCol]==SAND&&randRow+1<grid.length)
      {
          if(grid[randRow+1][randCol]==EMPTY)
          {
              grid[randRow+1][randCol]=SAND;
              grid[randRow][randCol]=EMPTY;
              
          }
          else if(grid[randRow+1][randCol]==WATER)
          {
              grid[randRow+1][randCol]=SAND;
              grid[randRow][randCol]=WATER;
          }
      }
      if(grid[randRow][randCol]==WATER
              &&randRow+1<grid.length
              &&randCol<grid[0].length-1
              &&randCol-1>-1)
      {
          
          Random rand2 = new Random();
          double randDir = rand2.nextDouble();
          if(randDir >= .66)
          {
              System.out.println("a");
            if(grid[randRow+1][randCol]==EMPTY)
            {
                grid[randRow+1][randCol]=WATER;
                grid[randRow][randCol]=EMPTY;

            }
          }
          else if(randDir >= .33)
          {
              System.out.println("b");
            if(grid[randRow][randCol+1]==EMPTY)
            {
                grid[randRow][randCol+1]=WATER;
                grid[randRow][randCol]=EMPTY;

            }
          }
          else
          {
              System.out.println("c");
            if(grid[randRow][randCol-1]==EMPTY&&randCol<grid.length)
            {
                grid[randRow][randCol-1]=WATER;
                grid[randRow][randCol]=EMPTY;

            }
          }
      }
  }
  
  //do not modify
  public void run()
  {
    while (true)
    {
      for (int i = 0; i < display.getSpeed(); i++)
        step();
      updateDisplay();
      display.repaint();
      display.pause(1);  //wait for redrawing and for mouse
      int[] mouseLoc = display.getMouseLocation();
      if (mouseLoc != null)  //test if mouse clicked
        locationClicked(mouseLoc[0], mouseLoc[1], display.getTool());
    }
  }
}
