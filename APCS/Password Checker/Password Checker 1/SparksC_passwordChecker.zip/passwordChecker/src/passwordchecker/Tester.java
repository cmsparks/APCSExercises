/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package passwordchecker;

/**
 *
 * @author dyanek
 */
public class Tester {

    /**
     * @param args the command line arguments
     */
    /*
    public static void main(String[] args) {
        // TODO code application logic here
        Password wordCheck = new Password("Aasdfsdf?11");
        wordCheck.getDictionary();
        System.out.println("Password Length: "+wordCheck.getLength());
        System.out.println(wordCheck.hasDigit());
        System.out.println(wordCheck.hasLowercase());
        System.out.println(wordCheck.hasUppercase());
        System.out.println(wordCheck.hasSymbol());
        System.out.println(wordCheck.noThreeChars());
        System.out.println(wordCheck.testDictionary());
    }
    */
}
