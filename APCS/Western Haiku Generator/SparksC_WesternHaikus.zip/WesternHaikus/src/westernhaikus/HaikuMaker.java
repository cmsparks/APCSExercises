/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package westernhaikus;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;
import java.util.stream.IntStream;

/**
 *
 * @author your name
 */
public class HaikuMaker {
    
    private String text;
    private String haiku;
    private ArrayList<String> wordList;
    private int[] haikuSize = {0,0,0};

    public HaikuMaker(String t) {
       setText(t);
       getWordList();
       setHaikuLength();
       createHaiku();
    }

    public void setText(String t) {
        //your code here
        text = t;
    }

    public void setHaikuLength() {
       //your code here
       Random rand = new Random();
       int r = rand.nextInt(2);
       if(r == 0)
       {
           haikuSize[0] = 3;
           haikuSize[2] = 3;
       }
       else
       {
           haikuSize[0] = 4;
           haikuSize[2] = 4;
       }
       r = rand.nextInt(2);
       if(r == 0)
       {
           haikuSize[1] = 3;
       }
       else
       {
           haikuSize[1] = 4;
       }
    }

    public String getText() {
        //your code here
       Random rand = new Random();
       int word = rand.nextInt(wordList.size());
       System.out.print(word);
       return wordList.get(word);
    }   
    
    public void getWordList() {
        /*wordList = new ArrayList<>();
        text = text.trim();
        int index1 = 0;
        while(text.contains(" "))
        {
            int index2 = text.indexOf(' ');
            String word = text.substring(index1,index2);
            wordList.add(word);
            System.out.print(word);
            text = text.replaceFirst(" ", "/");
            index1 = index2;
        }
        
        /*
        wordList = new ArrayList<>();
        Scanner sc = new Scanner(text);
        while(sc.hasNext())
        {
            String i = sc.next();
            wordList.add(i);
            System.out.print(i);
        }
        sc.close();*/
        String[] words = text.split("\\W+");
        wordList = new ArrayList( Arrays.asList(words) );
    }
    
    
    
    public void createHaiku()
    {
        haiku = "";
        for(int i = 0; i<haikuSize[0]; i++)
        {
            haiku = haiku+" "+getText();
        }
        haiku = haiku+"\n";
        for(int i = 0; i<haikuSize[1]; i++)
        {
            haiku = haiku+" "+getText();
        }
        haiku = haiku+"\n";
        for(int i = 0; i<haikuSize[2]; i++)
        {
            haiku = haiku+" "+getText();
        }
    }
    
    public String getHaiku()
    {
        return haiku;
    }
    
    @Override
    public String toString() {
        return "HaikuMaker{" + "text=" + text + ", haiku=" + haiku + '}';
    }
}
