/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mountainpath;

import java.util.*;
import java.io.*;
import java.awt.*;

public class MapDataDrawer
{

  private int[][] grid;
  public ArrayList<String> lineList;
  
  public MapDataDrawer(String filename, int rows, int cols){
      // initialize grid 
      //read the data from the file into the grid
      grid = new int[rows][cols];
      int row = 0;
      //get each line
      try
      {
          BufferedReader reader = new BufferedReader(new FileReader(filename));
          String line;
          while((line = reader.readLine()) != null)
          {
              line = line.trim();
              line = line.replaceAll("   ", " ");
              String[] s = line.split(" ");
              for(int i = 0; i < s.length; i++)
              {
                  int n = Integer.parseInt(s[i]);
                  grid[row][i] = n;
              }
              row++;
          }
          System.out.println("\nFile Read");
          reader.close();
      }
      catch (Exception e)
      {
        System.out.print(e);
      }
  }
  
  /**
   * @return the min value in the entire grid
   */
  public int findMinValue(){
    int min = grid[0][0];
    for(int r = 0; r < grid.length; r++)
    {
        for(int c = 0; c < grid[0].length; c++)
        {
            if(grid[r][c] < min)
            {
                min = grid[r][c];
            }
        }
    }
    return min;
  }
  /**
   * @return the max value in the entire grid
   */
  public int findMaxValue(){
    int max = grid[0][0];
    for(int r = 0; r < grid.length; r++)
    {
        for(int c = 0; c < grid[0].length; c++)
        {
            if(grid[r][c] > max)
            {
                max = grid[r][c];
            }
        }
    }
    return max;
  }
  
  /**
   * @param col the column of the grid to check
   * @return the index of the row with the lowest value in the given col for the grid
   */
  public  int indexOfMinInCol(int col){
    int minRow = 0;
    for(int r = 0; r < grid.length; r++)
    {
        if(grid[r][col] < grid[minRow][col])
        {
            minRow = r;
        }
    }
    return minRow;
  }
  
  /**
   * Draws the grid using the given Graphics object.
   * Colors should be grayscale values 0-255, scaled based on min/max values in grid
   */
  public void drawMap(Graphics g){
      int baseMin = this.findMinValue();
      int baseMax = this.findMaxValue();
      for(int r = 0; r < grid.length; r++)
      {
          for(int c = 0; c < grid[0].length; c++)
          {
              grid[r][c] = scale(grid[r][c], baseMin, baseMax, 0, 255);
          }
      }
      for(int r = 0; r < grid.length; r++)
      {
          for(int c = 0; c < grid[0].length; c++)
          {
              Color color = new Color(grid[r][c],grid[r][c],grid[r][c]);
              g.setColor(color);
              g.drawLine(c, r, c, r);
          }
      }
  }
     
  public int scale(int valueIn, int baseMin, int baseMax, int limitMin, int limitMax) 

  {
      return (int)(((limitMax - limitMin) * (valueIn - baseMin) / (baseMax - baseMin)) + limitMin);
  }
  public int elevChange(int r1,int c1,int r2,int c2)
  {
      return Math.abs(grid[r1][c1]-grid[r2][c2]);
  }

  public int findPath(int row, int col)
  {
      int dir = 0;

        if(col==0)
        {
            int down = elevChange(row,col,row+1,col+1);
            int forward = elevChange(row,col,row+1,col);
            if(forward>down)
            {
                dir = 1;
            }
            else if(forward == down)
            {
              double r = Math.random();
              if(r>.5)
              {
                  dir = 1;
              }
              else if(r<=.5)
              {
                  dir = 0;
              }
            }
        }
        else if(col==grid.length-1)
        {
          int up = elevChange(row,col,row+1,col-1);
          int forward = elevChange(row,col,row+1,col);
          if(forward>up)
          {
              dir = -1;
          }
          else if(forward == up)
            {
              double r = Math.random();
              if(r>.5)
              {
                  dir = -1;
              }
              else if(r<=.5)
              {
                  dir = 0;
              }
            }
        }
        else
        {
          int up = elevChange(row,col,row+1,col-1);
          int down = elevChange(row,col,row+1,col+1);
          int forward = elevChange(row,col,row+1,col);
              if(forward>down && forward>up)
              {
                  if(up<down)
                  {
                      dir = -1;
                  }
                  else if(down<up)
                  {
                      dir = 1;
                  }
                  else if(down == up)
                  {
                      double r = Math.random();
                      if(r>.5)
                      {
                          dir = -1;
                      }
                      else if(r<=.5)
                      {
                          dir = 1;
                      }
                  }
              }
            else if(forward == down)
            {
              double r = Math.random();
              if(r>.5)
              {
                  dir = 1;
              }
              else if(r<=.5)
              {
                  dir = 0;
              }
            }
            else if(forward == up)
            {
              double r = Math.random();
              if(r>.5)
              {
                  dir = 0;
              }
              else if(r<=.5)
              {
                  dir = -1;
              }
            }
            else
            {
                dir = 0;
            }
        }
      return dir;
  }
   /**
   * Find a path from West-to-East starting at given row.
   * Choose a forward step out of 3 possible forward locations, using greedy method described in assignment.
   * @return the total change in elevation traveled from West-to-East
   */
  public int drawLowestElevPath(Graphics g, int col){
    int row = 0;
    int count = 0;
    int total = 0;
    col++;
    g.drawRect(row, col, 1, 1);
    for(row = 0; row<grid.length-1; row++)
    {

            int dir = findPath(row,col);
            if(dir==-1)
            {
                g.drawRect(row+1,col+1,1,1);
                count = elevChange(row,col,row+1,col+1);
                col=col+1;
            }
            else if(dir==0)
            {
                g.drawRect(row, col+1, 1, 1);
                count = elevChange(row,col,row,col+1);
            }
            else if(dir==1)
            {
                g.drawRect(row+1,col-1,1,1);
                count = elevChange(row,col,row+1,col-1);
                col=col-1;
            }
        total = count+total;
    }
    return total;
  }
  public boolean notOnEdge(int r,int c)
  {
      boolean notOnEdge = false;
      if(r<grid.length
        &&c<grid[0].length
        &&r+1<grid.length
        &&c+1<grid[0].length
        &&c-1<grid[0].length)
      {
          notOnEdge = true;
      }
      else if(r>0
            &&c>0
            &&r+1>0
            &&c+1>0
            &&c-1>0)
      {
          notOnEdge = true;
      }
      return notOnEdge;
  }
  /**
   * @return the index of the starting row for the lowest-elevation-change path in the entire grid.
   */
  public int indexOfLowestElevPath(Graphics g){
      int index = 0;
      int count = 0;
      count = drawLowestElevPath(g,0);
      for(int col = 0; col < grid.length-1; col++)
      {
          if(count > drawLowestElevPath(g,col))
          {
              count = drawLowestElevPath(g,col);
          }
      }
      return count;
  }
}
