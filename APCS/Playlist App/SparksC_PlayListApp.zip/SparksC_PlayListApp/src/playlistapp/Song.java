/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package playlistapp;

/**
 *
 * @author ??????
 */
public class Song {
    private String artist;
    private String title;
    
    public Song(String a, String t)
    {
        artist = a;
        title = t;
    }
    
    public String getArtist()
    {
        return artist;
    }
    
    public boolean equals(Song s){
        if(this.getArtist().equals(s.getArtist()))
        if(this.getTitle().equals(s.getTitle())) return true;
    return false;
    }
    
    public String getTitle()
    {
        return title;
    }
    
    public void setArtist(String a)
    {
        artist = a;
    }
    
    public void setTitle(String t)
    {
        title = t;
    }
    
    
    
    public String toString()
    {
        return title + " – " + artist;
    }
    
}
