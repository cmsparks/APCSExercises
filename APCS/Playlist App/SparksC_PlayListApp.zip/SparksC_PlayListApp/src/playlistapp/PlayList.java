/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package playlistapp;

import java.util.ArrayList;

/**
 *
 * @author Christian Sparks
 */
public class PlayList {
    private ArrayList<Song> list;
    
    //instantiate Arraylist list
    public PlayList()
    {
        list = new ArrayList<Song>();
        Song s = new Song("sdfasdf","sdafdfs");
        list.add(s);
    }
    
    //add a new song object to list
    public void addSong(String artist, String title)
    {
        Song s = new Song(artist,title);
        list.add(s);
    }
    
    //remove song from list. HINT: find index of song first and use list.emove(index)
    public void removeSong(String artist, String title)
    {
        Song s = new Song(artist,title);
        for(int i = 0; i<list.size();i++)
        {
            if(list.get(i).equals(s))
            {
                list.remove(i);
            }
        }
    }
    
    //replace an existing song in the list. List size should not change
    public void replaceSong(int index, String artist, String title)
    {
       Song s = new Song(artist,title);
       list.set(index, s);
    }
    
    //return the size of list
    public int getSize()
    {
        return list.size();
    }
    
    
    //removes a song from list at given index. size changes.
    public void removeIndex(int i)
    {
       list.remove(i);
    }
    
    //inserts a song at the desired index. list size changes
    public void insertSong(int index, String artist, String title)
    {
        Song s = new Song(artist,title);
        list.add(index,s);
    }
    
    //returns song at index
    public Song getSong(int index)
    {
        return list.get(index);
    }
    
    //deletes all items in the list. list sisze will be zero
    public void deleteList()
    {
        list.clear();
    }
    
    //returns ArrayList list as determined by Song.toString()
    public String toString()
    {
        return "" + list;
    }
    
}
