/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sparksc_karelprojects;

import java.awt.Color;

/**
 *
 * @author CSLAB313-1740
 */
public class RectangleBot extends AdvRobot {
    public RectangleBot(int street, int avenue, Direction d, int beepers, Color c) {
        super(street, avenue, d, beepers, c);
    }
    public void makeRow(int width)
    {
        for(int i = 0; i < width; i++)
        {
            this.move();
            this.putBeeper();
        }
    }
    public void goToNextRowL()
    {
        this.move();
        this.turnRight();
        this.move();
        this.turnRight();
    }
    public void goToNextRowR()
    {
        this.move();
        this.turnLeft();
        this.move();
        this.turnLeft();
    }
    public void makeRectangle(int length, int width)
    {
        for(int i = 0; i < length; i++)
        {
            this.makeRow(width);
            if(facingWest())
            {
                goToNextRowL();
            }
            else if(facingEast())
            {
                goToNextRowR();
            }
            else if(facingNorth())
            {
                goToNextRowL();
            }
            else if(facingSouth())
            {
                goToNextRowR();
            }
        }
    }
}
