/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sparksc_karelprojects;
import kareltherobot.*;
import java.awt.Color;

/**
 *
 * @author Christian Sparks
 */
public class Tester implements Directions{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        AdvRobot robbie = new AdvRobot(4,3,East,0,Color.GREEN);
        
        robbie.move(2);
	robbie.turnLeft();
	robbie.move();
	robbie.pickBeeper();
	robbie.move();
	robbie.pickBeeper();
	robbie.turnAround();
	robbie.move(3);
	robbie.pickBeeper();
	robbie.move();
	robbie.pickBeeper();
	robbie.turnAround();
	robbie.move(2);
	robbie.turnLeft();
	robbie.move();
	robbie.putBeeper();
	robbie.move();
	robbie.putBeeper();
	robbie.turnAround();
	robbie.move(3);
	robbie.putBeeper();
	robbie.move();
	robbie.putBeeper();
	robbie.turnAround();
	robbie.move(2);
	robbie.turnLeft();
	robbie.move(2);
	robbie.turnAround();
	
	robbie.turnOff();
    }
    
    static {
        World.readWorld("fig2-11.kwld");
        World.setSize(10, 10);
        World.smallView(600);
        World.setDelay(15);
        World.setVisible();
    }
}
